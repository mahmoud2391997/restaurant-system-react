import mongoose, { Schema, Document, Types } from "mongoose";

// Type extension
declare module 'mongoose' {
  interface SchemaOptions {
    strictPopulate?: boolean;
  }
}

interface Ingredient {
  inventoryItemId: Types.ObjectId;
  quantity: number;
  unit: string;
}

export interface IRecipe extends Document {
  _id: Types.ObjectId;
  name: string;
  description?: string;
  menuItemId: Types.ObjectId;
  category: string;
  ingredients: Ingredient[];
  id: string;
}

const IngredientSchema = new Schema<Ingredient>(
  {
    inventoryItemId: { 
      type: Schema.Types.ObjectId, 
      ref: "InventoryItem", 
      required: true 
    },
    quantity: { type: Number, required: true },
    unit: { type: String, required: true },
  },
  { _id: false }
);

const RecipeSchema = new Schema<IRecipe>(
  {
    name: { type: String, required: true },
    description: { type: String },
    menuItemId: {
      type: Schema.Types.ObjectId,
      ref: "MenuItem",
      required: true
    },
    category: { type: String, required: true },
    ingredients: { type: [IngredientSchema], required: true },
  },
  {
    timestamps: true,
    strictPopulate: false, // Now properly typed
    toJSON: {
      virtuals: true,
      versionKey: false,
      transform: (_doc, ret) => {
        delete ret._id;
        delete ret.__v;
      },
    }
  }
);

RecipeSchema.virtual("id").get(function (this: IRecipe) {
  return this._id.toHexString();
});

export default mongoose.model<IRecipe>("Recipe", RecipeSchema);