import morgan from "morgan";

export const logger = morgan("dev");
