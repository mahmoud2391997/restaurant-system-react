"use client"

import { useState, useEffect } from "react"
import { useAppDispatch, useAppSelector } from '@/store/hooks'
import {
  fetchInventoryItems,
  fetchInventoryItemById,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  fetchStockMovements,
  createStockMovement,
  fetchStockAdjustments,
  createStockAdjustment,
  createRecipe,
  fetchRecipes,
  setSearch,
  setFilters,
  clearFilters,
  setSort,
  setPage,
  setLimit,
  clearSelectedItem,
  fetchStockMovementById
} from "@/store/slices/inventorySlice"

import {
  selectInventoryItems,
  selectInventoryLoading,
  selectInventoryError,
  selectInventoryPagination,
  selectInventoryFilters,
  selectInventorySearch,
  selectInventorySort,
  selectSelectedInventoryItem,
  selectStockMovements,
  selectStockAdjustments,
  selectRecipes
} from "@/store/slices/inventorySlice"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table"
import {
  Package,
  AlertTriangle,
  TrendingDown,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  ArrowUpDown,
  MoreHorizontal,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { InventoryItem, StockAdjustment, Recipe, QueryParams, StockMovement } from "../types/entities"
import { InventoryItemForm } from "@/components/inventory/InventoryItemForm"
import { StockAdjustmentForm } from "../components/inventory/StockAdjustmentForm"
import { RecipeForm } from "../components/inventory/RecipeForm"
import { StockMovementForm } from "../components/inventory/StockMovementForm"
import { useToast } from "../../components/ui/use-toast"
import { Skeleton } from "../../components/ui/skeleton"

export default function InventoryManagement() {
  const dispatch = useAppDispatch()
  const { toast } = useToast()
  
  const [activeTab, setActiveTab] = useState("all-items")
  const [isItemFormOpen, setIsItemFormOpen] = useState(false)
  const [isAdjustmentFormOpen, setIsAdjustmentFormOpen] = useState(false)
  const [isMovementFormOpen, setIsMovementFormOpen] = useState(false)
  const [isRecipeFormOpen, setIsRecipeFormOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null)
  const [selectedAdjustmentItem, setSelectedAdjustmentItem] = useState<InventoryItem | null>(null)

  // Select state from Redux store
  const {
    items,
    loading,
    error,
    stockMovements,
    stockAdjustments,
    recipes,
    selectedItem,
    search,
    filters,
    sort,
    page,
    limit,
    total,
    totalPages
  } = useAppSelector((state) => ({
    items: selectInventoryItems(state),
    loading: selectInventoryLoading(state),
    error: selectInventoryError(state),
    stockMovements: selectStockMovements(state),
    stockAdjustments: selectStockAdjustments(state),
    recipes: selectRecipes(state),
    selectedItem: selectSelectedInventoryItem(state),
    search: selectInventorySearch(state),
    filters: selectInventoryFilters(state),
    sort: selectInventorySort(state),
    ...selectInventoryPagination(state)
  }))

  // Fetch data when tab or filters change
  useEffect(() => {
    const params: QueryParams = {
      page,
      limit,
      search,
      sort,
      filters: {
        ...filters,
        // Ensure we only pass defined filters
        ...(activeTab === 'low-stock' ? { minimum_stock: true } : {})
      }
    }

    switch (activeTab) {
      case 'all-items':
      case 'low-stock':
        dispatch(fetchInventoryItems(params))
        break
      case 'movements':
        dispatch(fetchStockMovements(params))
        break
      case 'adjustments':
        dispatch(fetchStockAdjustments(params))
        break
      case 'recipes':
        dispatch(fetchRecipes(params))
        break
    }
  }, [dispatch, activeTab, page, limit, search, sort, filters])

  const handleSelectItem = (item: InventoryItem) => {
    dispatch(fetchInventoryItemById(item.id))
    dispatch(fetchStockMovementById(item.id ))
  }

  const handleCreateItem = async (item: Omit<InventoryItem, "id">) => {
    try {
      await dispatch(createInventoryItem(item)).unwrap()
      toast({
        title: "Success",
        description: "Inventory item created successfully",
        variant: "default",
      })
      setIsItemFormOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create inventory item",
        variant: "destructive",
      })
    }
  }

  const handleUpdateItem = async (item: InventoryItem) => {
    try {
      await dispatch(updateInventoryItem({ id: item.id, data: item })).unwrap()
      toast({
        title: "Success",
        description: "Inventory item updated successfully",
        variant: "default",
      })
      setIsItemFormOpen(false)
      setEditingItem(null)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update inventory item",
        variant: "destructive",
      })
    }
  }

  const handleDeleteItem = async (id: string) => {
    try {
      await dispatch(deleteInventoryItem(id)).unwrap()
      toast({
        title: "Success",
        description: "Inventory item deleted successfully",
        variant: "default",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete inventory item",
        variant: "destructive",
      })
    }
  }

  const handleSearch = (term: string) => {
    dispatch(setSearch(term))
    dispatch(setPage(1))
  }

  const handleStockAdjustment = async (adjustment: Omit<StockAdjustment, "id" | "createdAt">) => {
    try {
      await dispatch(createStockAdjustment(adjustment)).unwrap()
      toast({
        title: "Success",
        description: "Stock adjustment recorded successfully",
        variant: "default",
      })
      setIsAdjustmentFormOpen(false)
      setSelectedAdjustmentItem(null)
      
      // Refresh relevant data
      if (selectedAdjustmentItem) {
        dispatch(fetchInventoryItemById(selectedAdjustmentItem.id))
        dispatch(fetchStockMovementById(selectedAdjustmentItem.id ))
      }
      dispatch(fetchStockAdjustments({ page, limit }))
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to record stock adjustment",
        variant: "destructive",
      })
    }
  }

  const handleCreateMovement = async (movement: Omit<StockMovement, "id" | "created_at">) => {
    try {
      await dispatch(createStockMovement(movement)).unwrap()
      toast({
        title: "Success",
        description: "Stock movement recorded successfully",
        variant: "default",
      })
      setIsMovementFormOpen(false)
      
      // Refresh relevant data
      if (selectedItem) {
        dispatch(fetchInventoryItemById(selectedItem.id))
        dispatch(fetchStockMovementById( selectedItem.id) )
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to record stock movement",
        variant: "destructive",
      })
    }
  }

const handleCreateRecipe = async (data: {
  menuItemId: string;
  ingredients: { ingredientId: string; quantity: number }[];
}) => {
  try {
    const recipePayload = {
      id: data.menuItemId,
      name: `Recipe for ${data.menuItemId}`,
      description: "Auto-generated recipe",
      ingredients: data.ingredients.map((ing) => ({
        inventoryItemId: ing.ingredientId,
        quantity: ing.quantity
      })),
    };

    await dispatch(createRecipe(recipePayload)).unwrap();

    toast({
      title: "Success",
      description: "Recipe created successfully",
      variant: "default",
    });

    setIsRecipeFormOpen(false);
  } catch (error) {
    toast({
      title: "Error",
      description: "Failed to create recipe",
      variant: "destructive",
    });
  }
};

  const handleSort = (field: string) => {
    const order = sort.field === field && sort.order === "asc" ? "desc" : "asc"
    dispatch(setSort({ field, order }))
  }

  const getStatusBadge = (item: InventoryItem) => {
    if (item.locked) {
      return <Badge variant="secondary">Locked</Badge>
    }
    if (item.currentStock <= 0) {
      return <Badge variant="destructive">Out of Stock</Badge>
    }
    if (item.currentStock <= item.minimumStock) {
      return <Badge variant="secondary">Low Stock</Badge>
    }
    return <Badge variant="default">In Stock</Badge>
  }

  // Calculate stats
  const lowStockItems = items.filter(item => item.currentStock <= item.minimumStock)
  const totalValue = items.reduce((sum, item) => sum + (item.currentStock * (item.costPerUnit || 0)), 0)
  const lockedItems = items.filter(item => item.locked).length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Inventory Management</h1>
          <p className="text-muted-foreground">Track and manage your inventory items</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button onClick={() => {
            setEditingItem(null)
            setIsItemFormOpen(true)
          }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{total}</div>
            <p className="text-xs text-muted-foreground">Active inventory items</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {lowStockItems.length}
            </div>
            <p className="text-xs text-muted-foreground">Items need attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${totalValue.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Current inventory value</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Locked Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {lockedItems}
            </div>
            <p className="text-xs text-muted-foreground">Items not available</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all-items">All Items</TabsTrigger>
            <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
            <TabsTrigger value="movements">Movements</TabsTrigger>
            <TabsTrigger value="adjustments">Adjustments</TabsTrigger>
            <TabsTrigger value="recipes">Recipes</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search inventory..."
                className="pl-10 w-64"
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuLabel>Filter by</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuCheckboxItem
                  checked={filters.minimum_stock === true}
                  onCheckedChange={(checked) => dispatch(setFilters({ minimum_stock: checked || undefined }))}
                >
                  Low Stock Only
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filters.category === "raw"}
                  onCheckedChange={(checked) => dispatch(setFilters({ category: checked ? "raw" : undefined }))}
                >
                  Raw Materials
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filters.category === "semi-finished"}
                  onCheckedChange={(checked) => dispatch(setFilters({ category: checked ? "semi-finished" : undefined }))}
                >
                  Semi-Finished
                </DropdownMenuCheckboxItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => dispatch(clearFilters())}>
                  Clear Filters
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <TabsContent value="all-items">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Inventory Items</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => dispatch(setPage(Math.max(1, page - 1)))}
                    disabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => dispatch(setPage(Math.min(totalPages, page + 1)))}
                    disabled={page === totalPages}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading && !items.length ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : error ? (
                <p className="text-red-500">{error}</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead onClick={() => handleSort("name")}>
                        Name <ArrowUpDown className="inline" />
                      </TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead onClick={() => handleSort("currentStock")}>
                        Current Stock <ArrowUpDown className="inline" />
                      </TableHead>
                      <TableHead>Min Stock</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead onClick={() => handleSort("costPerUnit")}>
                        Cost/Unit <ArrowUpDown className="inline" />
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id} onClick={() => handleSelectItem(item)} className="cursor-pointer">
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.type}</TableCell>
                        <TableCell>{item.currentStock}</TableCell>
                        <TableCell>{item.minimumStock}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell>${item.costPerUnit.toFixed(2)}</TableCell>
                        <TableCell>{getStatusBadge(item)}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setEditingItem(item)
                                setIsItemFormOpen(true)
                              }}>
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {
                                setSelectedAdjustmentItem(item)
                                setIsAdjustmentFormOpen(true)
                              }}>
                                Adjust Stock
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDeleteItem(item.id)}>
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="low-stock">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                Low Stock Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : error ? (
                <p className="text-red-500">{error}</p>
              ) : lowStockItems.length === 0 ? (
                <p className="text-muted-foreground">No low stock items found.</p>
              ) : (
                <div className="space-y-4">
                  {lowStockItems.map((item) => (
                    <div key={item.id} className="border rounded p-4 flex justify-between items-center bg-orange-50">
                      <div>
                        <h3 className="font-medium">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Current: {item.currentStock} | Min: {item.minimumStock} | Unit: {item.unit}
                        </p>
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => {
                          setSelectedAdjustmentItem(item)
                          setIsAdjustmentFormOpen(true)
                        }}
                      >
                        Adjust Stock
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="movements">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Stock Movements</CardTitle>
                <Button onClick={() => setIsMovementFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Movement
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : error ? (
                <div className="text-red-500">{error}</div>
              ) : stockMovements.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Package className="h-12 w-12 mx-auto mb-4" />
                  <p>No stock movements found</p>
                  <p className="text-sm">Select an item to view its movement history</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stockMovements.map((movement) => (
                      <TableRow key={movement.id}>
                        <TableCell>
                          {new Date(movement.created_at).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {items.find(item => item.id === movement.inventory_item_id)?.name || 'N/A'}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {movement.movement_type}
                          </Badge>
                        </TableCell>
                        <TableCell className={movement.movement_type === 'in' ? 'text-green-600' : 'text-red-600'}>
                          {movement.movement_type === 'in' ? '+' : '-'}{movement.quantity}
                        </TableCell>
                        <TableCell>
                          {movement.reference_type && (
                            <Badge variant="secondary">
                              {movement.reference_type}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {movement.notes}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="adjustments">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Stock Adjustments</CardTitle>
                <Button onClick={() => setIsAdjustmentFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  New Adjustment
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : error ? (
                <p className="text-red-500">{error}</p>
              ) : stockAdjustments.length === 0 ? (
                <p className="text-muted-foreground">No stock adjustments found.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stockAdjustments.map((adj) => (
                      <TableRow key={adj.id}>
                        <TableCell>{new Date(adj.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>{items.find(i => i.id === adj.itemId)?.name || adj.itemId}</TableCell>
                        <TableCell>{adj.quantity}</TableCell>
                        <TableCell>{adj.adjustmentType}</TableCell>
                        <TableCell>{adj.notes || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recipes">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Recipes</CardTitle>
                <Button onClick={() => setIsRecipeFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Recipe
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : error ? (
                <p className="text-red-500">{error}</p>
              ) : recipes.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Package className="h-12 w-12 mx-auto mb-4" />
                  <p>No recipes found</p>
                  <Button className="mt-4" onClick={() => setIsRecipeFormOpen(true)}>
                    Add Recipe
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Ingredients</TableHead>
                      <TableHead>Yield</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recipes.map((recipe) => (
                      <TableRow key={recipe.id}>
                        <TableCell>{recipe.name}</TableCell>
                        {/* <TableCell>
                          {recipe.ingredients.map(ing => `${ing.quantity} ${ing.unit} ${ing.name}`).join(', ')}
                        </TableCell>
                        <TableCell>{recipe.yieldQuantity} {recipe.yieldUnit}</TableCell> */}
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Forms */}
      <InventoryItemForm
        open={isItemFormOpen}
        onOpenChange={(open) => {
          setIsItemFormOpen(open)
          if (!open) setEditingItem(null)
        }}
        item={editingItem}
        onSubmit={editingItem ? 
          (data) => handleUpdateItem({ ...data, id: editingItem.id }) : 
          handleCreateItem
        }
      />

      <StockAdjustmentForm
        open={isAdjustmentFormOpen}
        onOpenChange={(open) => {
          setIsAdjustmentFormOpen(open)
          if (!open) setSelectedAdjustmentItem(null)
        }}
        item={selectedAdjustmentItem}
        onSubmit={handleStockAdjustment}
      />

      <StockMovementForm
        open={isMovementFormOpen}
        onOpenChange={setIsMovementFormOpen}
        items={items.map(item => ({ id: item.id, name: item.name }))}
        onSubmit={handleCreateMovement}
      />

      <RecipeForm
        open={isRecipeFormOpen}
        onOpenChange={setIsRecipeFormOpen}
        onSubmit={handleCreateRecipe}
        inventoryItems={items.map(item => ({
          id: item.id,
          name: item.name,
          unit: item.unit
        }))}
      />
    </div>
  )
}