// src/app/pos/page.tsx
"use client";

import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  fetchMenuItems,
  fetchCategories,
  fetchTables,
  fetchCustomers,
  fetchModifiers,
  fetchKitchenOrders,
  fetchUnpaidOrders,
  fetchTransactions,
  createKitchenOrder,
  updateKitchenOrderItemState,
  createTransaction,
  selectFilteredMenuItems,
  selectCategories,
  selectTables as selectTablesByZone,
  selectCustomers,
  selectModifiers,
  selectFilteredKitchenOrders,
  selectReadyForPaymentOrders,
  selectTransactions,
  selectCart,
  selectSelectedTable,
  selectSelectedCustomer,
  selectOrderType,
  selectSearchTerm,
  selectSelectedCategory,
  selectSpecialInstructions,
  selectKitchenStatusFilter,
  selectKitchenStationFilter,
  selectPaymentDiscountAmount,
  selectPaymentDiscountType,
  selectSplitPayment,
  selectSplitAmounts,
  selectSelectedOrderForPayment,
  selectCartSubtotal,
  setSelectedTable,
  setSelectedCustomer,
  setOrderType,
  setSearchTerm,
  setSelectedCategory,
  setSpecialInstructions,
  setKitchenStatusFilter,
  setKitchenStationFilter,
  setPaymentDiscountAmount,
  setPaymentDiscountType,
  setSplitPayment,
  setSplitAmounts,
  setSelectedOrderForPayment,
  addToCart,
  updateCartItemQuantity,
  removeFromCart,
  clearCart,
  updateElapsedTimes,
} from "../store/slices/pos";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import {
  Plus,
  Minus,
  Trash2,
  CreditCard,
  Banknote,
  Smartphone,
  Search,
  Clock,
  MapPin,
  ShoppingCart,
  User,
  Phone,
  Wifi,
  WifiOff,
  Globe,
  ChefHat,
  Receipt,
  Eye,
  Play,
  CheckCircle,
  AlertTriangle,
  Filter,
  DollarSign,
  TrendingUp,
} from "lucide-react";

import type { MenuItem, Table, Customer } from "@/types/entities";
import type { KitchenOrder, KitchenOrderItem } from "@/types/entities";

interface ModifierOption {
  type: "single" | "multiple";
  options: string[];
}

interface ItemModifiers {
  [category: string]: ModifierOption;
}

interface MockModifiers {
  [menuId: string]: ItemModifiers;
}

export default function ThreeTabPOSSystem() {
  const dispatch = useAppDispatch();
  
  // Select data from Redux store
  const menuItems = useAppSelector(selectFilteredMenuItems);
  const categories = useAppSelector(selectCategories);
  const tablesByZone = useAppSelector(selectTablesByZone);
  const customers = useAppSelector(selectCustomers);
  const modifiers = useAppSelector(selectModifiers);
  const kitchenOrders = useAppSelector(selectFilteredKitchenOrders);
  const readyForPaymentOrders = useAppSelector(selectReadyForPaymentOrders);
  const transactions = useAppSelector(selectTransactions);
  const cart = useAppSelector(selectCart);
  const selectedTable = useAppSelector(selectSelectedTable);
  const selectedCustomer = useAppSelector(selectSelectedCustomer);
  const orderType = useAppSelector(selectOrderType);
  const searchTerm = useAppSelector(selectSearchTerm);
  const selectedCategory = useAppSelector(selectSelectedCategory);
  const specialInstructions = useAppSelector(selectSpecialInstructions);
  const kitchenStatusFilter = useAppSelector(selectKitchenStatusFilter);
  const kitchenStationFilter = useAppSelector(selectKitchenStationFilter);
  const paymentDiscountAmount = useAppSelector(selectPaymentDiscountAmount);
  const paymentDiscountType = useAppSelector(selectPaymentDiscountType);
  const splitPayment = useAppSelector(selectSplitPayment);
  const splitAmounts = useAppSelector(selectSplitAmounts);
  const selectedOrderForPayment = useAppSelector(selectSelectedOrderForPayment);
  const cartSubtotal = useAppSelector(selectCartSubtotal);

  // UI state
  const [activeTab, setActiveTab] = useState("ordering");
  const [language, setLanguage] = useState<"en" | "ar">("en");
  const [isOnline, setIsOnline] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Modifier dialog state
  const [isModifierDialogOpen, setIsModifierDialogOpen] = useState(false);
  const [selectedMenuItem, setSelectedMenuItem] = useState<MenuItem | null>(null);
  const [currentModifiers, setCurrentModifiers] = useState<Record<string, string>>({});
  const [itemSpecialInstructions, setItemSpecialInstructions] = useState("");

  // Mock modifiers data
  const mockModifiers: MockModifiers = {
    "MENU-001": {
      Size: { type: "single", options: ["Small (+$0)", "Medium (+$2)", "Large (+$4)"] },
      Crust: { type: "single", options: ["Thin", "Thick", "Stuffed (+$3)"] },
      "Extra Toppings": {
        type: "multiple",
        options: ["Extra Cheese (+$2)", "Pepperoni (+$3)", "Mushrooms (+$1)", "Olives (+$1)"],
      },
    },
    "MENU-002": {
      Size: { type: "single", options: ["Regular", "Large (+$3)"] },
      Dressing: { type: "single", options: ["Caesar", "Ranch", "Italian"] },
      "Add-ons": { type: "multiple", options: ["Grilled Chicken (+$4)", "Croutons", "Extra Parmesan (+$1)"] },
    },
    "MENU-003": {
      Cooking: { type: "single", options: ["Rare", "Medium Rare", "Medium", "Medium Well", "Well Done"] },
      Cheese: { type: "single", options: ["No Cheese", "American (+$1)", "Cheddar (+$1)", "Swiss (+$1)"] },
      Extras: { type: "multiple", options: ["Bacon (+$2)", "Avocado (+$2)", "Extra Patty (+$5)", "Onion Rings (+$2)"] },
    },
    "MENU-004": {
      Size: { type: "single", options: ["Regular", "Large (+$3)"] },
      Sauce: { type: "single", options: ["Marinara", "Alfredo (+$2)", "Pesto (+$2)", "Carbonara (+$3)"] },
      "Add-ons": {
        type: "multiple",
        options: ["Grilled Chicken (+$4)", "Shrimp (+$6)", "Extra Cheese (+$2)", "Garlic Bread (+$3)"],
      },
    },
  };

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchMenuItems());
    dispatch(fetchCategories());
    dispatch(fetchTables());
    dispatch(fetchCustomers());
    dispatch(fetchModifiers());
    dispatch(fetchKitchenOrders());
    dispatch(fetchUnpaidOrders());
    dispatch(fetchTransactions());
  }, [dispatch]);

  // Update elapsed times every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      dispatch(updateElapsedTimes());
    }, 1000);

    return () => clearInterval(timer);
  }, [dispatch]);

  // Helper functions
  const getItemStation = (menuItemId: string): "grill" | "fryer" | "salad" | "dessert" | "beverage" | "main" => {
    const stationMap: Record<string, any> = {
      "MENU-001": "main",
      "MENU-002": "salad",
      "MENU-003": "grill",
      "MENU-004": "main",
      "MENU-005": "grill",
      "MENU-006": "fryer",
      "MENU-007": "beverage",
    };
    return stationMap[menuItemId] || "main";
  };

  const getEstimatedTime = (menuItemId: string): number => {
    const timeMap: Record<string, number> = {
      "MENU-001": 15,
      "MENU-002": 5,
      "MENU-003": 12,
      "MENU-004": 18,
      "MENU-005": 20,
      "MENU-006": 8,
      "MENU-007": 3,
    };
    return timeMap[menuItemId] || 10;
  };

  const calculateModifierPrice = (menuItemId: string, modifiers: Record<string, string>): number => {
    const itemModifiers = mockModifiers[menuItemId as keyof typeof mockModifiers];
    if (!itemModifiers) return 0;

    let totalPrice = 0;
    Object.entries(modifiers).forEach(([category, selection]) => {
      if (itemModifiers[category]) {
        if (itemModifiers[category].type === "single") {
          const match = selection.match(/\(\+\$(\d+)\)/);
          if (match) totalPrice += Number.parseFloat(match[1]);
        } else {
          const selections = selection.split(", ");
          selections.forEach((sel) => {
            const match = sel.match(/\(\+\$(\d+)\)/);
            if (match) totalPrice += Number.parseFloat(match[1]);
          });
        }
      }
    });
    return totalPrice;
  };

  const handleAddToCart = (item: MenuItem, modifiers?: Record<string, string>, instructions?: string) => {
    const cartItemId = `${item.id}-${JSON.stringify(modifiers || {})}-${instructions || ""}`;
    const existingItem = cart.find((cartItem) => cartItem.id === cartItemId);
    const station = getItemStation(item.id);
    const estimatedTime = getEstimatedTime(item.id);
    const price = item.price + calculateModifierPrice(item.id, modifiers || {});

    if (existingItem) {
      dispatch(updateCartItemQuantity({ id: cartItemId, change: 1 }));
    } else {
      dispatch(
        addToCart({
          id: cartItemId,
          menuItemId: item.id,
          name: item.name,
          price,
          quantity: 1,
          modifiers: modifiers || {},
          specialInstructions: instructions,
          station,
          estimatedTime,
        })
      );
    }
  };

  const handleSendToKitchen = () => {
    if (cart.length === 0) {
      alert("Cart is empty!");
      return;
    }

    if (orderType === "dine-in" && !selectedTable) {
      alert("Please select a table for dine-in orders");
      return;
    }

    const orderNumber = `${Date.now().toString().slice(-3)}`;
    const newKitchenOrder = {
      id:"SAdsdfsd",
      orderNumber,
      tableNumber: selectedTable?.number,
      customerName: selectedCustomer?.first_name,
      orderType,
      items: cart.map((item) => ({
        menuItemId: item.menuItemId,
        name: item.name,
        quantity: item.quantity,
        modifiers: item.modifiers,
        specialInstructions: item.specialInstructions,
        status: "pending",
        estimatedTime: item.estimatedTime,
        station: item.station,
      })),
      priority: "normal",
      status: "new",
      orderTime: new Date().toISOString(),
      totalEstimatedTime: Math.max(...cart.map((item) => item.estimatedTime)),
      elapsedTime: 0,
      isRushed: false,
      specialNotes: specialInstructions,
        paid:true

    };

    dispatch(createKitchenOrder(newKitchenOrder));
  };

  const handleUpdateItemStatus = (orderId: string, itemId: string, newStatus: KitchenOrderItem["status"]) => {
    dispatch(updateKitchenOrderItemState({ orderId, itemId, status: newStatus }));
  };

  const handleProcessPayment = (paymentMethod: string) => {
    if (!selectedOrderForPayment) return;

    const subtotal = selectedOrderForPayment.items.reduce((sum, item) => {
      const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
      return sum + (menuItem?.price || 0) * item.quantity;
    }, 0);

    const discountAmount =
      paymentDiscountType === "percentage" ? subtotal * (paymentDiscountAmount / 100) : paymentDiscountAmount;

    const afterDiscount = subtotal - discountAmount;
    const tax = afterDiscount * 0.1;
    const total = afterDiscount + tax;

    const newTransaction = {
      orderNumber: selectedOrderForPayment.orderNumber,
      tableNumber: selectedOrderForPayment.tableNumber,
      customerName: selectedOrderForPayment.customerName,
      orderType: selectedOrderForPayment.orderType,
      items: selectedOrderForPayment.items.map((item) => {
        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
        return {
          menuItemId: item.menuItemId,
          name: item.name,
          price: menuItem?.price || 0,
          quantity: item.quantity,
          modifiers: item.modifiers,
          specialInstructions: item.specialInstructions,
          station: item.station,
          estimatedTime: item.estimatedTime || 0,
        };
      }),
      subtotal,
      discount: discountAmount,
      tax,
      total,
      paymentMethod,
      status: "paid" as const,
      createdAt: new Date().toISOString(),
      paidAt: new Date().toISOString(),
    };

    dispatch(createTransaction(newTransaction));
  };

  const openModifierDialog = (item: MenuItem) => {
    setSelectedMenuItem(item);
    setCurrentModifiers({});
    setItemSpecialInstructions("");
    setIsModifierDialogOpen(true);
  };

  const handleModifierChange = (category: string, option: string, isMultiple: boolean) => {
    if (isMultiple) {
      const currentSelections = currentModifiers[category] ? currentModifiers[category].split(", ") : [];
      const newSelections = currentSelections.includes(option)
        ? currentSelections.filter((sel) => sel !== option)
        : [...currentSelections, option];

      setCurrentModifiers((prev) => ({
        ...prev,
        [category]: newSelections.join(", "),
      }));
    } else {
      setCurrentModifiers((prev) => ({
        ...prev,
        [category]: option,
      }));
    }
  };

  const addItemWithModifiers = () => {
    if (selectedMenuItem) {
      handleAddToCart(selectedMenuItem, currentModifiers, itemSpecialInstructions);
      setIsModifierDialogOpen(false);
      setSelectedMenuItem(null);
      setCurrentModifiers({});
      setItemSpecialInstructions("");
    }
  };

  const updateQuantity = (id: string, change: number) => {
    dispatch(updateCartItemQuantity({ id, change }));
  };

  const removeItemFromCart = (id: string) => {
    dispatch(removeFromCart(id));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold">Restaurant POS System</h1>
            <Badge variant={isOnline ? "default" : "destructive"} className="flex items-center gap-1">
              {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
              {isOnline ? "Online" : "Offline"}
            </Badge>
            <Badge variant="outline" className="text-sm">
              {currentTime.toLocaleTimeString()}
            </Badge>
          </div>

          <div className="flex items-center gap-4">
            <Select value={language} onValueChange={(value: "en" | "ar") => setLanguage(value)}>
              <SelectTrigger className="w-32">
                <Globe className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="ar">العربية</SelectItem>
              </SelectContent>
            </Select>

            <Select value={orderType} onValueChange={(value: any) => dispatch(setOrderType(value))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dine-in">Dine In</SelectItem>
                <SelectItem value="takeaway">Takeaway</SelectItem>
                <SelectItem value="delivery">Delivery</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="p-6">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="ordering" className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4" />
            Making Order to Kitchen
          </TabsTrigger>
          <TabsTrigger value="kitchen" className="flex items-center gap-2">
            <ChefHat className="h-4 w-4" />
            Kitchen Orders ({kitchenOrders.length})
          </TabsTrigger>
          <TabsTrigger value="payment" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Order Payment ({readyForPaymentOrders.length})
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Making Order to Kitchen */}
        <TabsContent value="ordering" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Menu and Selection */}
            <div className="lg:col-span-2 space-y-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search menu items..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => dispatch(setSearchTerm(e.target.value))}
                />
              </div>

              {/* Table Selection for Dine-in */}
              {orderType === "dine-in" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5" />
                      Table Selection
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(tablesByZone).map(([zone, zoneTables]) => (
                        <div key={zone}>
                          <h3 className="font-medium mb-2">{zone}</h3>
                          <div className="grid grid-cols-5 gap-2">
                            {zoneTables.map((table) => (
                              <Button
                                key={table.id}
                                variant={selectedTable?.id === table.id ? "default" : "outline"}
                                className="h-12"
                                onClick={() => dispatch(setSelectedTable(table))}
                              >
                                {table.number}
                              </Button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Customer Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Customer Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Select
                    value={selectedCustomer?.id || "guest"}
                    onValueChange={(value) => {
                      const customer = customers.find((c) => c.id === value);
                      dispatch(setSelectedCustomer(customer || null));
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer or continue as guest" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="guest">Guest Customer</SelectItem>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.first_name} - {customer.phone}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Menu Categories */}
              <Tabs value={selectedCategory} onValueChange={(value) => dispatch(setSelectedCategory(value))} className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  {["All", ...categories.map((cat) => cat.name)].slice(0, 4).map((category) => (
                    <TabsTrigger key={category} value={category}>
                      {category}
                    </TabsTrigger>
                  ))}
                </TabsList>

                <TabsContent value={selectedCategory} className="mt-6">
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                    {menuItems.map((item) => (
                      <Card
                        key={item.id}
                        className="cursor-pointer transition-all hover:shadow-md"
                        onClick={() => {
                          const itemModifiers = modifiers[item.id as keyof typeof modifiers];
                          if (itemModifiers && Object.keys(itemModifiers).length > 0) {
                            openModifierDialog(item);
                          } else {
                            handleAddToCart(item);
                          }
                        }}
                      >
                        <CardContent className="p-4">
                          <div className="aspect-square bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                            <span className="text-gray-400">Image</span>
                          </div>
                          <h3 className="font-medium text-sm mb-1">{item.name}</h3>
                          <p className="text-xs text-gray-500 mb-2 line-clamp-2">{item.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-bold">${item.price.toFixed(2)}</span>
                            <div className="flex flex-col items-end gap-1">
                              <Badge variant="outline" className="text-xs">
                                {getItemStation(item.id)}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {getEstimatedTime(item.id)}min
                              </Badge>
                              {modifiers[item.id as keyof typeof modifiers] && (
                                <Badge variant="default" className="text-xs bg-blue-500">
                                  Customizable
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Right Column - Cart */}
            <div className="space-y-6">
              <Card className="h-fit">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      Current Order
                    </span>
                    <div className="flex flex-col items-end text-sm gap-1">
                      {orderType === "dine-in" && selectedTable && (
                        <Badge variant="outline">Table {selectedTable.number}</Badge>
                      )}
                      <Badge variant="secondary">{orderType}</Badge>
                    </div>
                  </CardTitle>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Customer Info */}
                  {selectedCustomer && (
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <User className="h-4 w-4" />
                        <span className="font-medium">{selectedCustomer.first_name}</span>
                        <Badge variant="outline">tier</Badge>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div className="flex items-center gap-2">
                          <Phone className="h-3 w-3" />
                          {selectedCustomer.phone}
                        </div>
                        <div>Loyalty Points: {selectedCustomer.loyalty_points}</div>
                      </div>
                    </div>
                  )}

                  {/* Cart Items */}
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {cart.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                        <p>No items in cart</p>
                      </div>
                    ) : (
                      cart.map((item) => (
                        <div key={item.id} className="p-3 border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{item.name}</h4>
                              <p className="text-sm text-gray-500">${item.price.toFixed(2)} each</p>
                              <div className="flex gap-1 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {item.station}
                                </Badge>
                                <Badge variant="secondary" className="text-xs">
                                  {item.estimatedTime}min
                                </Badge>
                              </div>
                              {item.modifiers && Object.keys(item.modifiers).length > 0 && (
                                <div className="mt-1">
                                  {Object.entries(item.modifiers).map(([key, value]) => (
                                    <Badge key={key} variant="outline" className="text-xs mr-1 mb-1">
                                      {key}: {value}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                              {item.specialInstructions && (
                                <p className="text-xs text-orange-600 mt-1">Note: {item.specialInstructions}</p>
                              )}
                            </div>
                            <Button
                              size="icon"
                              variant="outline"
                              className="h-8 w-8 text-red-500"
                              onClick={() => removeItemFromCart(item.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.id, -1)}
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="w-8 text-center">{item.quantity}</span>
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.id, 1)}
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                            <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Special Instructions */}
                  {cart.length > 0 && (
                    <>
                      <div>
                        <Label htmlFor="instructions">Special Instructions</Label>
                        <Textarea
                          id="instructions"
                          placeholder="Any special requests for the kitchen..."
                          value={specialInstructions}
                          onChange={(e) => dispatch(setSpecialInstructions(e.target.value))}
                          rows={2}
                        />
                      </div>

                      {/* Order Summary */}
                      <Separator />
                      <div className="space-y-2">
                        <div className="flex justify-between font-bold text-lg">
                          <span>Subtotal:</span>
                          <span>${cartSubtotal.toFixed(2)}</span>
                        </div>
                      </div>

                      {/* Send to Kitchen Button */}
                      <Button
                        onClick={handleSendToKitchen}
                        className="w-full"
                        size="lg"
                        disabled={cart.length === 0 || (orderType === "dine-in" && !selectedTable)}
                      >
                        <ChefHat className="h-4 w-4 mr-2" />
                        Send to Kitchen ({cart.length} items)
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Tab 2: Kitchen Orders */}
        <TabsContent value="kitchen" className="space-y-6">
          {/* Kitchen Filters */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span className="text-sm font-medium">Filters:</span>
            </div>

            <Select value={kitchenStatusFilter} onValueChange={(value) => dispatch(setKitchenStatusFilter(value))}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active Orders</SelectItem>
                <SelectItem value="ready">Ready Orders</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="all">All Orders</SelectItem>
              </SelectContent>
            </Select>

            <Select value={kitchenStationFilter} onValueChange={(value) => dispatch(setKitchenStationFilter(value))}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stations</SelectItem>
                <SelectItem value="grill">Grill</SelectItem>
                <SelectItem value="fryer">Fryer</SelectItem>
                <SelectItem value="salad">Salad</SelectItem>
                <SelectItem value="main">Main Kitchen</SelectItem>
                <SelectItem value="beverage">Beverage</SelectItem>
                <SelectItem value="dessert">Dessert</SelectItem>
              </SelectContent>
            </Select>

            <Badge variant="outline">
              {kitchenOrders.length} order{kitchenOrders.length !== 1 ? "s" : ""}
            </Badge>
          </div>

          {/* Kitchen Orders Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {kitchenOrders.map((order) => (
              <Card
                key={order.id}
                className={`border-l-4 ${
                  order.status === "new"
                    ? "border-l-red-500"
                    : order.status === "preparing"
                      ? "border-l-yellow-500"
                      : order.status === "ready"
                        ? "border-l-green-500"
                        : "border-l-gray-500"
                }`}
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">#{order.orderNumber}</CardTitle>
                      <p className="text-sm text-gray-500">
                        {order.tableNumber ? `Table ${order.tableNumber}` : order.customerName || order.orderType}
                      </p>
                    </div>
                    <Badge
                      className={`text-xs ${
                        order.status === "ready"
                          ? "bg-green-500"
                          : order.status === "preparing"
                            ? "bg-yellow-500"
                            : "bg-gray-500"
                      } text-white`}
                    >
                      {order.status}
                    </Badge>
                  </div>

                  {/* Timer */}
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>
                          {order.elapsedTime}min / {order.totalEstimatedTime}min
                        </span>
                      </div>
                      {order.elapsedTime !== undefined && 
                        order.totalEstimatedTime !== undefined && 
                        order.elapsedTime > order.totalEstimatedTime && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          DELAYED
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  {/* Order Items */}
                  <div className="space-y-2">
                    {order.items.map((item) => (
                      <div
                        key={item.id}
                        className={`border rounded-lg p-3 transition-all ${
                          item.status === "preparing"
                            ? "bg-yellow-50 border-yellow-200"
                            : item.status === "ready"
                              ? "bg-green-50 border-green-200"
                              : "bg-gray-50"
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">
                                {item.quantity}x {item.name}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {item.station}
                              </Badge>
                            </div>

                            {item.modifiers && Object.keys(item.modifiers).length > 0 && (
                              <div className="mt-1 flex flex-wrap gap-1">
                                {Object.entries(item.modifiers).map(([key, value]) => (
                                  <Badge key={key} variant="secondary" className="text-xs">
                                    {key}: {value}
                                  </Badge>
                                ))}
                              </div>
                            )}

                            {item.specialInstructions && (
                              <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
                                <div className="flex items-center gap-1 text-yellow-800">
                                  <Eye className="h-3 w-3" />
                                  <span className="font-medium">Note:</span>
                                </div>
                                <p className="text-yellow-700 mt-1">{item.specialInstructions}</p>
                              </div>
                            )}
                          </div>

                          <Badge
                            className={`text-xs ml-2 ${
                              item.status === "ready"
                                ? "bg-green-500"
                                : item.status === "preparing"
                                  ? "bg-yellow-500"
                                  : "bg-gray-500"
                            } text-white`}
                          >
                            {item.status}
                          </Badge>
                        </div>

                        {/* Item Actions */}
                        <div className="flex gap-2 mt-2">
                          {item.status === "pending" && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="flex-1 text-xs"
                              onClick={() => handleUpdateItemStatus(order.id, item.id, "preparing")}
                            >
                              <Play className="h-3 w-3 mr-1" />
                              Start
                            </Button>
                          )}

                          {item.status === "preparing" && (
                            <Button
                              size="sm"
                              className="flex-1 text-xs bg-green-600 hover:bg-green-700"
                              onClick={() => handleUpdateItemStatus(order.id, item.id, "ready")}
                            >
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Ready
                            </Button>
                          )}

                          {item.status === "ready" && (
                            <div className="flex-1 flex items-center justify-center bg-green-100 rounded text-green-800 text-xs font-medium py-1">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Ready to Serve
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Order Actions */}
                  <Separator />
                  <div className="flex gap-2"></div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Empty State */}
          {kitchenOrders.length === 0 && (
            <div className="text-center py-12">
              <ChefHat className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No kitchen orders</h3>
              <p className="text-gray-500">No orders match the current filters.</p>
            </div>
          )}
        </TabsContent>

        {/* Tab 3: Order Payment */}
        <TabsContent value="payment" className="space-y-6">
          {/* Payment Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-8 w-8 text-orange-600" />
                  <div>
                    <p className="text-sm text-gray-600">Ready Orders</p>
                    <p className="text-2xl font-bold">{readyForPaymentOrders.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-8 w-8 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Pending Amount</p>
                    <p className="text-2xl font-bold">
                      $
                      {readyForPaymentOrders
                        .reduce((sum, order) => {
                          const orderTotal = order.items.reduce((itemSum, item) => {
                            const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                            return itemSum + (menuItem?.price || 0) * item.quantity;
                          }, 0);
                          return sum + orderTotal * 1.1; // Including 10% tax
                        }, 0)
                        .toFixed(2)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Receipt className="h-8 w-8 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Today's Payments</p>
                    <p className="text-2xl font-bold">
                      {
                        transactions.filter((t) => new Date(t.createdAt).toDateString() === new Date().toDateString())
                          .length
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                  <div>
                    <p className="text-sm text-gray-600">Today's Revenue</p>
                    <p className="text-2xl font-bold">
                      $
                      {transactions
                        .filter((t) => new Date(t.createdAt).toDateString() === new Date().toDateString())
                        .reduce((sum, t) => sum + t.total, 0)
                        .toFixed(2)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ready Orders for Payment */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {readyForPaymentOrders.map((order) => {
              const orderSubtotal = order.items.reduce((sum, item) => {
                const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                return sum + (menuItem?.price || 0) * item.quantity;
              }, 0);
              const orderTax = orderSubtotal * 0.1;
              const orderTotal = orderSubtotal + orderTax;

              return (
                <Card key={order.id} className="border-l-4 border-l-green-500">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">#{order.orderNumber}</CardTitle>
                        <p className="text-sm text-gray-500">
                          {order.tableNumber ? `Table ${order.tableNumber}` : order.customerName || order.orderType}
                        </p>
                        <p className="text-xs text-gray-400">
                          Ready at: {order.actualCompletionTime ? new Date(order.actualCompletionTime).toLocaleString() : "Just now"}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-green-500 text-white mb-2">READY</Badge>
                        <p className="text-2xl font-bold">${orderTotal.toFixed(2)}</p>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    {/* Order Items */}
                    <div className="space-y-2">
                      {order.items.map((item) => {
                        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                        return (
                          <div key={item.id} className="flex justify-between text-sm">
                            <span>
                              {item.quantity}x {item.name}
                            </span>
                            <span>${((menuItem?.price || 0) * item.quantity).toFixed(2)}</span>
                          </div>
                        );
                      })}
                    </div>

                    <Separator />

                    {/* Order Summary */}
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>${orderSubtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tax (10%):</span>
                        <span>${orderTax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold">
                        <span>Total:</span>
                        <span>${orderTotal.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Payment Button */}
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => dispatch(setSelectedOrderForPayment(order))}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Process Payment
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Empty State */}
          {readyForPaymentOrders.length === 0 && (
            <div className="text-center py-12">
              <CreditCard className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No orders ready for payment</h3>
              <p className="text-gray-500">Orders will appear here when they're ready from the kitchen.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Enhanced Payment Dialog */}
      <Dialog open={!!selectedOrderForPayment} onOpenChange={() => dispatch(setSelectedOrderForPayment(null))}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Process Payment - Order #{selectedOrderForPayment?.orderNumber}</DialogTitle>
          </DialogHeader>
          {selectedOrderForPayment && (
            <div className="space-y-6">
              {/* Order Details */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Order Type:</span>
                    <p>{selectedOrderForPayment.orderType}</p>
                  </div>
                  {selectedOrderForPayment.tableNumber && (
                    <div>
                      <span className="font-medium">Table:</span>
                      <p>Table {selectedOrderForPayment.tableNumber}</p>
                    </div>
                  )}
                  {selectedOrderForPayment.customerName && (
                    <div>
                      <span className="font-medium">Customer:</span>
                      <p>{selectedOrderForPayment.customerName}</p>
                    </div>
                  )}
                  <div>
                    <span className="font-medium">Items:</span>
                    <p>{selectedOrderForPayment.items.reduce((sum, item) => sum + item.quantity, 0)} items</p>
                  </div>
                </div>
              </div>

              {/* Order Items */}
              <div className="space-y-2">
                <h4 className="font-medium">Order Items:</h4>
                {selectedOrderForPayment.items.map((item) => {
                  const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                  return (
                    <div key={item.id} className="flex justify-between text-sm border-b pb-1">
                      <span>
                        {item.quantity}x {item.name}
                      </span>
                      <span>${((menuItem?.price || 0) * item.quantity).toFixed(2)}</span>
                    </div>
                  );
                })}
              </div>

              {/* Discount Section */}
              <div className="space-y-3">
                <h4 className="font-medium">Discount (Optional):</h4>
                <div className="flex gap-2">
                  <Select
                    value={paymentDiscountType}
                    onValueChange={(value: "percentage" | "fixed") => dispatch(setPaymentDiscountType(value))}
                  >
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">%</SelectItem>
                      <SelectItem value="fixed">$</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    placeholder="0"
                    value={paymentDiscountAmount}
                    onChange={(e) => dispatch(setPaymentDiscountAmount(Number(e.target.value)))}
                  />
                </div>
              </div>

              {/* Split Payment Option */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="splitPayment"
                    checked={splitPayment}
                    onChange={(e) => dispatch(setSplitPayment(e.target.checked))}
                    className="rounded"
                  />
                  <Label htmlFor="splitPayment">Split Payment</Label>
                </div>
              </div>

              {/* Payment Summary */}
              <div className="space-y-2 p-4 bg-blue-50 rounded-lg">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>
                    $
                    {selectedOrderForPayment.items
                      .reduce((sum, item) => {
                        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                        return sum + (menuItem?.price || 0) * item.quantity;
                      }, 0)
                      .toFixed(2)}
                  </span>
                </div>
                {paymentDiscountAmount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount:</span>
                    <span>
                      -
                      {paymentDiscountType === "percentage"
                        ? `${paymentDiscountAmount}%`
                        : `$${paymentDiscountAmount.toFixed(2)}`}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Tax (10%):</span>
                  <span>
                    ${(() => {
                      const subtotal = selectedOrderForPayment.items.reduce((sum, item) => {
                        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                        return sum + (menuItem?.price || 0) * item.quantity;
                      }, 0);
                      const discountAmount =
                        paymentDiscountType === "percentage"
                          ? subtotal * (paymentDiscountAmount / 100)
                          : paymentDiscountAmount;
                      return ((subtotal - discountAmount) * 0.1).toFixed(2);
                    })()}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total:</span>
                  <span>
                    ${(() => {
                      const subtotal = selectedOrderForPayment.items.reduce((sum, item) => {
                        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
                        return sum + (menuItem?.price || 0) * item.quantity;
                      }, 0);
                      const discountAmount =
                        paymentDiscountType === "percentage"
                          ? subtotal * (paymentDiscountAmount / 100)
                          : paymentDiscountAmount;
                      const afterDiscount = subtotal - discountAmount;
                      const tax = afterDiscount * 0.1;
                      return (afterDiscount + tax).toFixed(2);
                    })()}
                  </span>
                </div>
              </div>

              {/* Payment Method Buttons */}
              <div className="space-y-2">
                <Button
                  className="w-full"
                  onClick={() => {
                    handleProcessPayment("card");
                    dispatch(setSelectedOrderForPayment(null));
                    dispatch(setPaymentDiscountAmount(0));
                    dispatch(setSplitPayment(false));
                  }}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Pay by Card
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    handleProcessPayment("cash");
                    dispatch(setSelectedOrderForPayment(null));
                    dispatch(setPaymentDiscountAmount(0));
                    dispatch(setSplitPayment(false));
                  }}
                >
                  <Banknote className="h-4 w-4 mr-2" />
                  Cash Payment
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    handleProcessPayment("mobile");
                    dispatch(setSelectedOrderForPayment(null));
                    dispatch(setPaymentDiscountAmount(0));
                    dispatch(setSplitPayment(false));
                  }}
                >
                  <Smartphone className="h-4 w-4 mr-2" />
                  Mobile Payment
                </Button>
              </div>

              {/* Cancel Button */}
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => {
                  dispatch(setSelectedOrderForPayment(null));
                  dispatch(setPaymentDiscountAmount(0));
                  dispatch(setSplitPayment(false));
                }}
              >
                Cancel
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modifier Selection Dialog */}
      <Dialog open={isModifierDialogOpen} onOpenChange={setIsModifierDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Customize Your Order</DialogTitle>
          </DialogHeader>
          {selectedMenuItem && (
            <div className="space-y-6">
              {/* Item Info */}
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                  <span className="text-xs text-gray-500">IMG</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{selectedMenuItem.name}</h3>
                  <p className="text-sm text-gray-600">{selectedMenuItem.description}</p>
                  <p className="text-lg font-bold text-green-600">
                    $
                    {(selectedMenuItem.price + calculateModifierPrice(selectedMenuItem.id, currentModifiers)).toFixed(2)}
                  </p>
                </div>
              </div>

              {/* Modifiers */}
              {modifiers[selectedMenuItem.id as keyof typeof modifiers] && (
                <div className="space-y-4">
                  {Object.entries(modifiers[selectedMenuItem.id as keyof typeof modifiers]).map(
                    ([category, config]) => (
                      <div key={category} className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-lg">{category}</h4>
                          <Badge variant="outline" className="text-xs">
                            {config.type === "single" ? "Choose One" : "Choose Multiple"}
                          </Badge>
                        </div>

                        <div className="grid gap-2">
                          {config.options.map((option) => {
                            const isSelected =
                              config.type === "single"
                                ? currentModifiers[category] === option
                                : currentModifiers[category]?.split(", ").includes(option) || false;

                            return (
                              <div
                                key={option}
                                className={`p-3 border rounded-lg cursor-pointer transition-all ${
                                  isSelected ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-gray-300"
                                }`}
                                onClick={() => handleModifierChange(category, option, config.type === "multiple")}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-medium">{option.replace(/\s*\(\+\$\d+\)/, "")}</span>
                                  <div className="flex items-center gap-2">
                                    {option.includes("(+$") && (
                                      <span className="text-green-600 font-medium">
                                        {option.match(/\(\+\$\d+\)/)?.[0]}
                                      </span>
                                    )}
                                    <div
                                      className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                                        isSelected ? "border-blue-500 bg-blue-500" : "border-gray-300"
                                      }`}
                                    >
                                      {isSelected && <CheckCircle className="w-3 h-3 text-white" />}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ),
                  )}
                </div>
              )}

              {/* Special Instructions */}
              <div className="space-y-2">
                <Label htmlFor="itemInstructions">Special Instructions (Optional)</Label>
                <Textarea
                  id="itemInstructions"
                  placeholder="Any special requests for this item..."
                  value={itemSpecialInstructions}
                  onChange={(e) => setItemSpecialInstructions(e.target.value)}
                  rows={3}
                />
              </div>

              {/* Selected Modifiers Summary */}
              {Object.keys(currentModifiers).length > 0 && (
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium mb-2">Selected Options:</h4>
                  <div className="space-y-1">
                    {Object.entries(currentModifiers).map(([category, selection]) => (
                      <div key={category} className="text-sm">
                        <span className="font-medium">{category}:</span> {selection}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button variant="outline" className="flex-1" onClick={() => setIsModifierDialogOpen(false)}>
                  Cancel
                </Button>
                <Button className="flex-1" onClick={addItemWithModifiers}>
                  Add to Cart - $
                  {(selectedMenuItem.price + calculateModifierPrice(selectedMenuItem.id, currentModifiers)).toFixed(2)}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}