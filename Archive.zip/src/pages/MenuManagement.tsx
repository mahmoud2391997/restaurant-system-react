"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { 
  fetchCategories,
  fetchModifiers,
  fetchItemModifiersByMenuItem,
  setCategoriesSearch,
  setModifiersSearch,
  selectCategories,
  selectModifiers,
  selectItemModifiers,
  selectCategoriesLoading,
  selectModifiersLoading,
  selectItemModifiersLoading,
  createCategory,
  addItemModifier,
  createMenuItem,
} from "../store/slices/menuSlice"
import { AppDispatch } from "../store/index"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table"
import { Plus, Search, Edit, Trash2, Eye, EyeOff, DollarSign, Package, TrendingUp, Settings, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../components/ui/dialog"
import { Label } from "../../components/ui/label"
import { Textarea } from "../../components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select"
import { Switch } from "../../components/ui/switch"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { toast } from "../../components/ui/use-toast"

// Form validation schemas
const menuItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  price: z.number().min(0.01, "Price must be greater than 0"),
  cost: z.number().min(0, "Cost cannot be negative"),
  category_id: z.string().min(1, "Category is required"),
  available: z.boolean().default(true),
  prep_time: z.number().min(1, "Prep time must be at least 1 minute").optional(),
  allergens: z.array(z.string()).optional(),
})

const categorySchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
})

const modifierSchema = z.object({
  menuItemId: z.string().min(1, "Menu item ID is required"),
  modifierId: z.string().min(1, "Modifier ID is required"),
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  price: z.number().min(0, "Price cannot be negative"),
});

type MenuItemFormData = z.infer<typeof menuItemSchema>
type CategoryFormData = z.infer<typeof categorySchema>
type ModifierFormData = z.infer<typeof modifierSchema>

export default function MenuManagement() {
  const dispatch = useDispatch<AppDispatch>()
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("items")
  const [openItemDialog, setOpenItemDialog] = useState(false)
  const [openCategoryDialog, setOpenCategoryDialog] = useState(false)
  const [openModifierDialog, setOpenModifierDialog] = useState(false)
  const [isCreating, setIsCreating] = useState(false)

  // Select data from Redux store
  const categories = useSelector(selectCategories) || []
console.log(categories)
  const modifiers = useSelector(selectModifiers)
  const itemModifiers = useSelector(selectItemModifiers)
  const categoriesLoading = useSelector(selectCategoriesLoading)
  const modifiersLoading = useSelector(selectModifiersLoading)
  const itemModifiersLoading = useSelector(selectItemModifiersLoading)

  // Sample menu items (replace with Redux data when available)
  const [menuItems, setMenuItems] = useState([
    {
      id: "MENU-001",
      name: "Margherita Pizza",
      description: "Fresh tomatoes, mozzarella, basil",
      price: 18.99,
      cost: 6.5,
      category_id: "CAT-001",
      available: true,
      popularity: 85,
      profit: 12.49,
      prep_time: 15,
      allergens: ["gluten", "dairy"],
    },
  ])

  // Form hooks
  const menuItemForm = useForm<MenuItemFormData>({
    resolver: zodResolver(menuItemSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      cost: 0,
      category_id: "",
      available: true,
      prep_time: 10,
      allergens: [],
    }
  })

  const categoryForm = useForm<CategoryFormData>({
    resolver: zodResolver(categorySchema),
    defaultValues: {
      name: "",
      description: "",
    }
  })

  const modifierForm = useForm<ModifierFormData>({
    resolver: zodResolver(modifierSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
    }
  })

  useEffect(() => {
    // Fetch initial data based on active tab
    switch (activeTab) {
      case "categories":
        dispatch(fetchCategories({ page: 1, limit: 10, search: "" }))
        break
      case "modifiers":
        dispatch(fetchModifiers({ page: 1, limit: 10, search: "" }))
        break
      case "items":
        // Fetch item modifiers for the first item as example
        if (menuItems.length > 0) {
          dispatch(fetchItemModifiersByMenuItem(menuItems[0].id))
        }
        break
    }
  }, [activeTab, dispatch])

  const handleSearch = (value: string) => {
    setSearchTerm(value)
    if (activeTab === "categories") {
      dispatch(setCategoriesSearch(value))
      dispatch(fetchCategories({ page: 1, limit: 10, search: value }))
    } else if (activeTab === "modifiers") {
      dispatch(setModifiersSearch(value))
      dispatch(fetchModifiers({ page: 1, limit: 10, search: value }))
    }
  }

  const onSubmitMenuItem = async (data: MenuItemFormData) => {
    setIsCreating(true)
    try {
      const newItem = {
        ...data,
        restaurant_id: "REST-001", // This should come from your auth/store
        popularity: 0,
        profit: data.price - data.cost,
        id: `MENU-${Math.floor(1000 + Math.random() * 9000)}`,
      }
      
      // In a real app, you would dispatch to Redux and handle the async response
      await dispatch(createMenuItem(newItem)).unwrap()
      
      // For demo purposes, we'll update local state
setMenuItems(prev => 
  prev.map(item => ({
    ...item,
    description: item.description ?? "Default description", // or handle appropriately
    prep_time: item.prep_time ?? 0,
    allergens: item.allergens ?? [],
  }))
);      
      toast({
        title: "Success",
        description: "Menu item created successfully",
        variant: "default",
      })
      
      setOpenItemDialog(false)
      menuItemForm.reset()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create menu item",
        variant: "destructive",
      })
      console.error("Creation failed:", error)
    } finally {
      setIsCreating(false)
    }
  }

  const onSubmitCategory = async (data: CategoryFormData) => {
    try {
      const newCategory = {
        ...data,
        id: `CAT-${Math.floor(1000 + Math.random() * 9000)}`
      }
      await dispatch(createCategory(newCategory)).unwrap()
      toast({
        title: "Success",
        description: "Category created successfully",
        variant: "default",
      })
      setOpenCategoryDialog(false)
      categoryForm.reset()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create category",
        variant: "destructive",
      })
    }
  }

  const onSubmitModifier = async (data: ModifierFormData) => {
    try {
      const newModifier = {
        ...data,
        id: `MOD-${Math.floor(1000 + Math.random() * 9000)}`
      }
      await dispatch(addItemModifier(newModifier)).unwrap()
      toast({
        title: "Success",
        description: "Modifier added successfully",
        variant: "default",
      })
      setOpenModifierDialog(false)
      modifierForm.reset()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add modifier",
        variant: "destructive",
      })
    }
  }

  const filteredItems = menuItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      categories.find(cat => cat.id === item.category_id)?.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalItems = menuItems.length
  const availableItems = menuItems.filter((item) => item.available).length
  const avgProfit = menuItems.reduce((sum, item) => sum + item.profit, 0) / menuItems.length
  const topPerformer = menuItems.reduce((prev, current) => (prev.popularity > current.popularity ? prev : current))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Menu Management</h1>
          <p className="text-muted-foreground">Manage your restaurant menu and pricing</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Settings className="h-4 w-4 mr-2" />
            Menu Settings
          </Button>
          
          {/* Add Item Dialog */}
          <Dialog open={openItemDialog} onOpenChange={setOpenItemDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Menu Item</DialogTitle>
              </DialogHeader>
              <form onSubmit={menuItemForm.handleSubmit(onSubmitMenuItem)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Item Name*</Label>
                    <Input 
                      id="name" 
                      placeholder="e.g. Margherita Pizza" 
                      {...menuItemForm.register("name")} 
                    />
                    {menuItemForm.formState.errors.name && (
                      <p className="text-sm text-red-500">{menuItemForm.formState.errors.name.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category_id">Category*</Label>
                    <Select 
                      onValueChange={(value) => menuItemForm.setValue("category_id", value)}
                      defaultValue={menuItemForm.getValues("category_id")}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category._id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {menuItemForm.formState.errors.category_id && (
                      <p className="text-sm text-red-500">{menuItemForm.formState.errors.category_id.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Item description" 
                    {...menuItemForm.register("description")} 
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Price*</Label>
                    <Input 
                      id="price" 
                      type="number" 
                      step="0.01" 
                      placeholder="0.00" 
                      {...menuItemForm.register("price", { valueAsNumber: true })} 
                    />
                    {menuItemForm.formState.errors.price && (
                      <p className="text-sm text-red-500">{menuItemForm.formState.errors.price.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cost">Cost</Label>
                    <Input 
                      id="cost" 
                      type="number" 
                      step="0.01" 
                      placeholder="0.00" 
                      {...menuItemForm.register("cost", { valueAsNumber: true })} 
                    />
                    {menuItemForm.formState.errors.cost && (
                      <p className="text-sm text-red-500">{menuItemForm.formState.errors.cost.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="prep_time">Prep Time (min)</Label>
                    <Input 
                      id="prep_time" 
                      type="number" 
                      placeholder="10" 
                      {...menuItemForm.register("prep_time", { valueAsNumber: true })} 
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="available" 
                    checked={menuItemForm.watch("available")} 
                    onCheckedChange={(checked) => menuItemForm.setValue("available", checked)}
                  />
                  <Label htmlFor="available">
                    {menuItemForm.watch("available") ? "Available" : "Unavailable"}
                  </Label>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setOpenItemDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isCreating}>
                    {isCreating ? "Creating..." : "Add Item"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalItems}</div>
            <p className="text-xs text-muted-foreground">All menu items</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available</CardTitle>
            {availableItems === totalItems ? (
              <Eye className="h-4 w-4 text-green-500" />
            ) : (
              <EyeOff className="h-4 w-4 text-yellow-500" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{availableItems}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((availableItems / totalItems) * 100)}% available
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${avgProfit.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Per item</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Performer</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{topPerformer.name}</div>
            <p className="text-xs text-muted-foreground">
              {topPerformer.popularity}% popularity
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="items" className="space-y-6" onValueChange={setActiveTab}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="items">Menu Items</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="engineering">Menu Engineering</TabsTrigger>
            <TabsTrigger value="modifiers">Modifiers</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder={`Search ${activeTab}...`}
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
              />
            </div>
          </div>
        </div>

        <TabsContent value="items">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Menu Items</CardTitle>
                <Dialog open={openItemDialog} onOpenChange={setOpenItemDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Item
                    </Button>
                  </DialogTrigger>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Cost</TableHead>
                    <TableHead>Profit</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => {
                    const category = categories.find(cat => cat.id === item.category_id)
                    return (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-3">
                            {item.name}
                            {item.allergens && item.allergens.length > 0 && (
                              <div className="flex gap-1">
                                {item.allergens.map(allergen => (
                                  <Badge key={allergen} variant="outline">
                                    {allergen}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                          {item.description && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {item.description}
                            </p>
                          )}
                        </TableCell>
                        <TableCell>{category?.name || "Uncategorized"}</TableCell>
                        <TableCell>${item.price.toFixed(2)}</TableCell>
                        <TableCell>${item.cost.toFixed(2)}</TableCell>
                        <TableCell>${item.profit.toFixed(2)}</TableCell>
                        <TableCell>
                          <Badge variant={item.available ? "default" : "secondary"}>
                            {item.available ? "Available" : "Unavailable"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Menu Categories</CardTitle>
                <Dialog open={openCategoryDialog} onOpenChange={setOpenCategoryDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Category
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Add New Category</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={categoryForm.handleSubmit(onSubmitCategory)} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="category-name">Category Name*</Label>
                        <Input 
                          id="category-name" 
                          placeholder="e.g. Pizza, Pasta, Desserts" 
                          {...categoryForm.register("name")} 
                        />
                        {categoryForm.formState.errors.name && (
                          <p className="text-sm text-red-500">{categoryForm.formState.errors.name.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="category-description">Description</Label>
                        <Textarea 
                          id="category-description" 
                          placeholder="Category description" 
                          {...categoryForm.register("description")} 
                        />
                      </div>
                      
                      <div className="flex justify-end gap-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setOpenCategoryDialog(false)}
                        >
                          Cancel
                        </Button>
                        <Button type="submit">Add Category</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {categoriesLoading ? (
                <div className="text-center py-8">Loading categories...</div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categories.map((category) => (
                    <Card key={category.id} className="border-2 hover:border-primary/50 cursor-pointer">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{category.name}</CardTitle>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <p className="text-sm text-muted-foreground">
                            {menuItems.filter(item => item.category_id === category.id).length} items
                          </p>
                          {category.description && (
                            <p className="text-sm">{category.description}</p>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="modifiers">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Menu Modifiers</CardTitle>
                <Dialog open={openModifierDialog} onOpenChange={setOpenModifierDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Modifier
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Add New Modifier</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={modifierForm.handleSubmit(onSubmitModifier)} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="modifier-name">Modifier Name*</Label>
                        <Input 
                          id="modifier-name" 
                          placeholder="e.g. Extra Cheese, Spicy Level" 
                          {...modifierForm.register("name")} 
                        />
                        {modifierForm.formState.errors.name && (
                          <p className="text-sm text-red-500">{modifierForm.formState.errors.name.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="modifier-description">Description</Label>
                        <Textarea 
                          id="modifier-description" 
                          placeholder="Modifier description" 
                          {...modifierForm.register("description")} 
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="modifier-price">Additional Price</Label>
                        <Input 
                          id="modifier-price" 
                          type="number" 
                          step="0.01" 
                          placeholder="0.00" 
                          {...modifierForm.register("price", { valueAsNumber: true })} 
                        />
                        {modifierForm.formState.errors.price && (
                          <p className="text-sm text-red-500">{modifierForm.formState.errors.price.message}</p>
                        )}
                      </div>
                      
                      <div className="flex justify-end gap-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setOpenModifierDialog(false)}
                        >
                          Cancel
                        </Button>
                        <Button type="submit">Add Modifier</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {modifiersLoading ? (
                <div className="text-center py-8">Loading modifiers...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {modifiers.map((modifier) => (
                      <TableRow key={modifier.id}>
                        <TableCell className="font-medium">{modifier.name}</TableCell>
                        <TableCell>{modifier.description}</TableCell>
                        <TableCell>${modifier.price?.toFixed(2)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}