'use client'

import { useEffect, useState } from 'react'
import {
  fetchAllOrders,
  fetchAllStations,
  fetchAllItems,
  selectAllOrders,
  selectAllStations,
  selectAllItems,
  selectKitchenLoading,
  selectKitchenError,
  clearError,
} from '../store/slices/kitchenSlice'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select'
import { Progress } from '@/components/ui/progress'
import {
  Clock,
  ChefHat,
  AlertTriangle,
  CheckCircle,
  Users,
  Utensils,
  Flame,
  Eye,
  Play,
  Pause,
  RotateCcw,
  Bell,
  Settings,
  Filter,
  RefreshCw,
} from 'lucide-react'
import { useAppDispatch, useAppSelector } from '@/store/hooks'
import { KitchenOrder, Order } from '@/types/entities'

export default function KitchenDisplaySystem() {
  const dispatch = useAppDispatch()
  const orders = useAppSelector(selectAllOrders)
  const stations = useAppSelector(selectAllStations)
  const items = useAppSelector(selectAllItems)
  const loading = useAppSelector(selectKitchenLoading)
  const error = useAppSelector(selectKitchenError)

  const [selectedStation, setSelectedStation] = useState<string>("all")
  const [selectedStatus, setSelectedStatus] = useState<string>("active")
  const [currentTime, setCurrentTime] = useState(new Date())
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [autoRefresh, setAutoRefresh] = useState(true)

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchAllOrders())
    dispatch(fetchAllStations())
    dispatch(fetchAllItems())
  }, [dispatch])

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Filter orders based on selected filters
  const filteredOrders = orders.filter((order) => {
    const stationMatch = selectedStation === "all" || 
      order.items.some((item) => item.station === selectedStation)
    const statusMatch =
      selectedStatus === "active"
        ? ["new", "preparing"].includes(order.status)
        : selectedStatus === "ready"
          ? order.status === "ready"
          : selectedStatus === "completed"
            ? ["served"].includes(order.status)
            : true

    return stationMatch && statusMatch
  })

  // Get priority color
  const getPriorityColor = (priority: string, isRushed: boolean) => {
    if (isRushed) return "bg-red-600"
    switch (priority) {
      case "urgent":
        return "bg-red-500"
      case "high":
        return "bg-orange-500"
      case "normal":
        return "bg-blue-500"
      case "low":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-purple-500"
      case "preparing":
        return "bg-yellow-500"
      case "ready":
        return "bg-green-500"
      case "served":
        return "bg-gray-500"
      case "delayed":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  // Calculate progress percentage
  const getProgressPercentage = (order: KitchenOrder) => {
    if (order.status === "served") return 100
    if (order.status === "ready") return 90
    if (order.totalEstimatedTime === 0) return 0
    
    // Calculate elapsed time in minutes
    const elapsedTime = Math.floor((Date.now() - new Date(order.orderTime).getTime()) / (1000 * 60))
    return Math.min((elapsedTime / order.totalEstimatedTime) * 100, 85)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-6 bg-red-50 rounded-lg max-w-md">
          <AlertTriangle className="h-12 w-12 mx-auto text-red-500 mb-4" />
          <h3 className="text-lg font-medium text-red-800 mb-2">Error loading kitchen data</h3>
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={() => dispatch(clearError())}>Try Again</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <ChefHat className="h-8 w-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-gray-900">Kitchen Display System</h1>
            <Badge variant="outline" className="text-lg px-3 py-1">
              {currentTime.toLocaleTimeString()}
            </Badge>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${autoRefresh ? "animate-spin" : ""}`} />
              Auto Refresh
            </Button>

            <Button
              variant={soundEnabled ? "default" : "outline"}
              size="sm"
              onClick={() => setSoundEnabled(!soundEnabled)}
            >
              <Bell className="h-4 w-4 mr-2" />
              Sound {soundEnabled ? "On" : "Off"}
            </Button>

            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Kitchen Stations Overview */}
        <div className="grid grid-cols-6 gap-4 mb-6">
          {stations.map((station) => (
            <Card
              key={station.id}
              className={`cursor-pointer transition-all ${
                selectedStation === station.id ? "ring-2 ring-blue-500" : ""
              }`}
              onClick={() => setSelectedStation(selectedStation === station.id ? "all" : station.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-sm">{station.name}</h3>
                  <Badge
                    variant={
                      station.status === "busy" ? "destructive" : station.status === "active" ? "default" : "secondary"
                    }
                  >
                    {station.status}
                  </Badge>
                </div>
                <div className="space-y-1 text-xs text-gray-600">
                  <div className="flex justify-between">
                    <span>Active Orders:</span>
                    <span className="font-medium">
                      {orders.filter(order => 
                        order.items.some(item => item.station === station.id) && 
                        ["new", "preparing"].includes(order.status)
                      ).length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span className="text-sm font-medium">Filters:</span>
          </div>

          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active Orders</SelectItem>
              <SelectItem value="ready">Ready Orders</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="all">All Orders</SelectItem>
            </SelectContent>
          </Select>

          <Badge variant="outline">
            {filteredOrders.length} order{filteredOrders.length !== 1 ? "s" : ""}
          </Badge>
        </div>
      </div>

      {/* Orders Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredOrders.map((order) => {
          const elapsedTime = Math.floor((Date.now() - new Date(order.orderTime).getTime()) / (1000 * 60))
          
          return (
            <Card
              key={order.id}
              className={`relative overflow-hidden border-l-4 ${getPriorityColor('normal', order.isRushed)} ${
                order.isRushed ? "animate-pulse" : ""
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl font-bold">#{order.orderNumber}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      {order.tableNumber ? (
                        <Badge variant="outline" className="text-xs">
                          <Users className="h-3 w-3 mr-1" />
                          Table {order.tableNumber}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          {order.customerName || "Takeaway"}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs">
                        {order.orderType}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    <Badge className={`text-xs ${getStatusColor(order.status)} text-white`}>
                      {order.status}
                    </Badge>
                    <Badge
                      variant={order.isRushed ? "destructive" : "secondary"}
                      className="text-xs"
                    >
                      {order.isRushed ? "RUSHED" : "NORMAL"}
                    </Badge>
                  </div>
                </div>

                {/* Timer and Progress */}
                <div className="mt-3">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>
                        {elapsedTime}min / {order.totalEstimatedTime}min
                      </span>
                    </div>
                    {elapsedTime > order.totalEstimatedTime && (
                      <Badge variant="destructive" className="text-xs">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        DELAYED
                      </Badge>
                    )}
                  </div>
                  <Progress
                    value={getProgressPercentage(order)}
                    className={`h-2 ${elapsedTime > order.totalEstimatedTime ? "bg-red-100" : "bg-gray-200"}`}
                  />
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                {/* Order Items */}
                <div className="space-y-2">
                  {order.items.map((item) => (
                    <div
                      key={item.id}
                      className={`border rounded-lg p-3 transition-all ${
                        item.status === "preparing"
                          ? "bg-yellow-50 border-yellow-200 shadow-md"
                          : item.status === "ready"
                            ? "bg-green-50 border-green-200 shadow-md"
                            : "bg-gray-50"
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">
                              {item.quantity}x {item.name}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {item.station}
                            </Badge>
                          </div>
                        </div>

                        <Badge
                          className={`text-xs ml-2 ${
                            item.status === "ready"
                              ? "bg-green-500"
                              : item.status === "preparing"
                                ? "bg-yellow-500"
                                : "bg-gray-500"
                          } text-white`}
                        >
                          {item.status}
                        </Badge>
                      </div>

                      {/* Item Timing Info */}
                      {item.estimatedTime && (
                        <div className="mt-2 text-xs text-gray-500">
                          <span>Est: {item.estimatedTime}min</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Rush Order Indicator */}
                {order.isRushed && (
                  <div className="absolute top-0 right-0 bg-red-600 text-white px-2 py-1 text-xs font-bold transform rotate-12 translate-x-2 -translate-y-1">
                    <Flame className="h-3 w-3 inline mr-1" />
                    RUSH
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Empty State */}
      {filteredOrders.length === 0 && (
        <div className="text-center py-12">
          <ChefHat className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No orders to display</h3>
          <p className="text-gray-500">
            {selectedStatus === "active"
              ? "All caught up! No active orders in the kitchen."
              : "No orders match the current filters."}
          </p>
        </div>
      )}
    </div>
  )
}