import { createSlice, createAsyncThunk, type PayloadAction } from "@reduxjs/toolkit"
import { get, post, put, del } from "../../services/api"
import type { InventoryItem, StockMovement, StockAdjustment, Recipe } from "../../types/entities"
import { type QueryParams, buildQueryString } from "../../utils/queryUtils"
import type { RootState } from "../index"

// Define the response type for paginated data
interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}

// Define the state type
interface InventoryState {
  items: InventoryItem[]
  selectedItem: InventoryItem | null
  stockMovements: StockMovement[]
  stockAdjustments: StockAdjustment[]
  recipes: Recipe[]
  loading: boolean
  error: string | null
  total: number
  page: number
  limit: number
  totalPages: number
  filters: {
    category?: string
    minimum_stock?: boolean
    supplier_id?: string
    adjustment_type?: string
  }
  search: string
  sort: {
    field: string
    order: "asc" | "desc"
  }
}

// Initial state
const initialState: InventoryState = {
  items: [],
  selectedItem: null,
  stockMovements: [],
  stockAdjustments: [],
  recipes: [],
  loading: false,
  error: null,
  total: 0,
  page: 1,
  limit: 10,
  totalPages: 0,
  filters: {},
  search: "",
  sort: {
    field: "name",
    order: "asc",
  },
}

// Async thunks
export const fetchInventoryItems = createAsyncThunk(
  "inventory/fetchItems",
  async (params: QueryParams, { rejectWithValue }) => {
    try {
      const queryString = buildQueryString(params)
      const response = await get<PaginatedResponse<InventoryItem>>(`/inventory/item?${queryString}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const fetchInventoryItemById = createAsyncThunk(
  "inventory/fetchItemById",
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await get<InventoryItem>(`/inventory/item/${id}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const createInventoryItem = createAsyncThunk(
  "inventory/createItem",
  async (item: Omit<InventoryItem, "id" | "created_at" | "updated_at">, { rejectWithValue }) => {
    try {
      const response = await post<InventoryItem>("/inventory/item", item)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const updateInventoryItem = createAsyncThunk(
  "inventory/updateItem",
  async ({ id, data }: { id: string; data: Partial<InventoryItem> }, { rejectWithValue }) => {
    try {
      const response = await put<InventoryItem>(`/inventory/item/${id}`, data)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const deleteInventoryItem = createAsyncThunk(
  "inventory/deleteItem", 
  async (id: string, { rejectWithValue }) => {
    try {
      await del(`/inventory/item/${id}`)
      return id
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const fetchStockMovementById = createAsyncThunk(
  "inventory/fetchStockMovements",
  async (itemId: string, { rejectWithValue }) => {
    try {
      const response = await get<StockMovement[]>(`/inventory/movement/${itemId}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)
export const fetchStockMovements = createAsyncThunk(
  "inventory/fetchStockMovements",
  async (params: QueryParams, { rejectWithValue }) => {
    try {
            const queryString = buildQueryString(params)

      const response = await get<StockMovement[]>(`/inventory/movement?${queryString}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)
export const fetchStockMovementsById = createAsyncThunk(
  "inventory/fetchStockMovementsById",
  async ({ itemId, params }: { itemId: string; params?: QueryParams }, { rejectWithValue }) => {
    try {
      let queryString = '';
      if (params) {
        queryString = buildQueryString(params);
      }

      const url = `/inventory/movement/${itemId}${queryString ? `?${queryString}` : ''}`;
      const response = await get<StockMovement[]>(url);
      return response;
    } catch (error) {
      return rejectWithValue((error as Error).message);
    }
  }
);

export const createStockMovement = createAsyncThunk(
  "inventory/createStockMovement",
  async (movement: Omit<StockMovement, "id" | "created_at">, { rejectWithValue }) => {
    try {
      const response = await post<StockMovement>("/inventory/movement", movement)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

// Stock Adjustments
export const fetchStockAdjustments = createAsyncThunk(
  "inventory/fetchStockAdjustments",
  async (params: QueryParams, { rejectWithValue }) => {
    try {
      const queryString = buildQueryString(params)
      const response = await get<PaginatedResponse<StockAdjustment>>(`/inventory/adjustment?${queryString}`)
      console.log(response);
      
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const createStockAdjustment = createAsyncThunk(
  "inventory/createStockAdjustment",
  async (adjustment: Omit<StockAdjustment, "id" | "createdAt">, { rejectWithValue }) => {
    try {
      const response = await post<StockAdjustment>("/inventory/adjustment", adjustment)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

// Recipes
export const fetchRecipes = createAsyncThunk(
  "inventory/fetchRecipes",
  async (params: QueryParams, { rejectWithValue }) => {
    try {
      const queryString = buildQueryString(params)
      const response = await get<PaginatedResponse<Recipe>>(`/inventory/recipe?${queryString}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const fetchRecipeById = createAsyncThunk(
  "inventory/fetchRecipeById",
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await get<Recipe>(`/inventory/recipe/${id}`)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const createRecipe = createAsyncThunk(
  "inventory/createRecipe",
  async (recipe: Omit<Recipe, "id" | "created_at">, { rejectWithValue }) => {
    try {
      const response = await post<Recipe>("/inventory/recipe", recipe)
      console.log(response);
      
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const updateRecipe = createAsyncThunk(
  "inventory/updateRecipe",
  async ({ id, data }: { id: string; data: Partial<Recipe> }, { rejectWithValue }) => {
    try {
      const response = await put<Recipe>(`/inventory/recipe/${id}`, data)
      return response
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

export const deleteRecipe = createAsyncThunk(
  "inventory/deleteRecipe", 
  async (id: string, { rejectWithValue }) => {
    try {
      await del(`/inventory/recipe/${id}`)
      return id
    } catch (error) {
      return rejectWithValue((error as Error).message)
    }
  }
)

// Create the slice
const inventorySlice = createSlice({
  name: "inventory",
  initialState,
  reducers: {
     createRecipe: (state, action: PayloadAction<Recipe>) => {
      state.recipes.push(action.payload);
    },
    updateRecipe: (state, action: PayloadAction<Recipe>) => {
      const index = state.recipes.findIndex(r => r.id === action.payload.id);
      if (index !== -1) {
        state.recipes[index] = action.payload;
      }
    },
    deleteRecipe: (state, action: PayloadAction<string>) => {
      state.recipes = state.recipes.filter(r => r.id !== action.payload);
    },
  
    setSearch: (state, action: PayloadAction<string>) => {
      state.search = action.payload
      state.page = 1
    },
    setFilters: (state, action: PayloadAction<Partial<InventoryState["filters"]>>) => {
      state.filters = { ...state.filters, ...action.payload }
      state.page = 1
    },
    clearFilters: (state) => {
      state.filters = {}
      state.page = 1
    },
    setSort: (state, action: PayloadAction<{ field: string; order: "asc" | "desc" }>) => {
      state.sort = action.payload
    },
    setPage: (state, action: PayloadAction<number>) => {
      state.page = action.payload
    },
    setLimit: (state, action: PayloadAction<number>) => {
      state.limit = action.payload
      state.page = 1
    },
    clearSelectedItem: (state) => {
      state.selectedItem = null
      state.stockMovements = []
    },
  },
  extraReducers: (builder) => {
    builder
      // Inventory Items
      .addCase(fetchInventoryItems.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchInventoryItems.fulfilled, (state, action) => {
        state.loading = false
        state.items = action.payload.data
        state.total = action.payload.total
        state.page = action.payload.page
        state.limit = action.payload.limit
        state.totalPages = action.payload.totalPages
      })
      .addCase(fetchInventoryItems.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(fetchInventoryItemById.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchInventoryItemById.fulfilled, (state, action) => {
        state.loading = false
        state.selectedItem = action.payload
      })
      .addCase(fetchInventoryItemById.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(createInventoryItem.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(createInventoryItem.fulfilled, (state, action) => {
        state.loading = false
        state.items.unshift(action.payload)
        state.total += 1
      })
      .addCase(createInventoryItem.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(updateInventoryItem.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(updateInventoryItem.fulfilled, (state, action) => {
        state.loading = false
        const index = state.items.findIndex((item) => item.id === action.payload.id)
        if (index !== -1) {
          state.items[index] = action.payload
        }
        if (state.selectedItem?.id === action.payload.id) {
          state.selectedItem = action.payload
        }
      })
      .addCase(updateInventoryItem.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(deleteInventoryItem.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(deleteInventoryItem.fulfilled, (state, action) => {
        state.loading = false
        state.items = state.items.filter((item) => item.id !== action.payload)
        state.total -= 1
        if (state.selectedItem?.id === action.payload) {
          state.selectedItem = null
        }
      })
      .addCase(deleteInventoryItem.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      // Stock Movements
      .addCase(fetchStockMovements.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchStockMovements.fulfilled, (state, action) => {
        state.loading = false
        state.stockMovements = action.payload
      })
      .addCase(fetchStockMovements.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(createStockMovement.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(createStockMovement.fulfilled, (state, action) => {
        state.loading = false
        state.stockMovements.unshift(action.payload)

        // Update inventory item stock
        if (state.selectedItem && state.selectedItem.id === action.payload.inventory_item_id) {
          if (action.payload.movement_type === "in") {
            state.selectedItem.currentStock += action.payload.quantity
          } else if (action.payload.movement_type === "out") {
            state.selectedItem.currentStock -= action.payload.quantity
          }
        }

        const itemIndex = state.items.findIndex((item) => item.id === action.payload.inventory_item_id)
        if (itemIndex !== -1) {
          if (action.payload.movement_type === "in") {
            state.items[itemIndex].currentStock += action.payload.quantity
          } else if (action.payload.movement_type === "out") {
            state.items[itemIndex].currentStock -= action.payload.quantity
          }
        }
      })
      .addCase(createStockMovement.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      // Stock Adjustments
      .addCase(fetchStockAdjustments.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchStockAdjustments.fulfilled, (state, action) => {
        state.loading = false
        state.stockAdjustments = action.payload.data
        state.total = action.payload.total
        state.page = action.payload.page
        state.limit = action.payload.limit
        state.totalPages = action.payload.totalPages
      })
      .addCase(fetchStockAdjustments.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(createStockAdjustment.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(createStockAdjustment.fulfilled, (state, action) => {
        state.loading = false
        state.stockAdjustments.unshift(action.payload)

        // Update inventory item stock
        const itemIndex = state.items.findIndex((item) => item.id === action.payload.itemId)
        if (itemIndex !== -1) {
          state.items[itemIndex].currentStock += action.payload.quantity
        }
      })
      .addCase(createStockAdjustment.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      // Recipes
      .addCase(fetchRecipes.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchRecipes.fulfilled, (state, action) => {
        state.loading = false
        state.recipes = action.payload.data
        state.total = action.payload.total
        state.page = action.payload.page
        state.limit = action.payload.limit
        state.totalPages = action.payload.totalPages
      })
      .addCase(fetchRecipes.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(fetchRecipeById.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchRecipeById.fulfilled, (state, action) => {
        state.loading = false
        // Add to recipes array or update if exists
        const index = state.recipes.findIndex((recipe) => recipe.id === action.payload.id)
        if (index === -1) {
          state.recipes.push(action.payload)
        } else {
          state.recipes[index] = action.payload
        }
      })
      .addCase(fetchRecipeById.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(createRecipe.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(createRecipe.fulfilled, (state, action) => {
        state.loading = false
        state.recipes.unshift(action.payload)
        state.total += 1
      })
      .addCase(createRecipe.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(updateRecipe.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(updateRecipe.fulfilled, (state, action) => {
        state.loading = false
        const index = state.recipes.findIndex((recipe) => recipe.id === action.payload.id)
        if (index !== -1) {
          state.recipes[index] = action.payload
        }
      })
      .addCase(updateRecipe.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })

      .addCase(deleteRecipe.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(deleteRecipe.fulfilled, (state, action) => {
        state.loading = false
        state.recipes = state.recipes.filter((recipe) => recipe.id !== action.payload)
        state.total -= 1
      })
      .addCase(deleteRecipe.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload as string
      })
  },
})

// Export actions
export const { 
  setSearch, 
  setFilters, 
  clearFilters, 
  setSort, 
  setPage, 
  setLimit, 
  clearSelectedItem 
} = inventorySlice.actions

// Export selectors
export const selectInventoryItems = (state: RootState) => state.inventory.items
export const selectInventoryLoading = (state: RootState) => state.inventory.loading
export const selectInventoryError = (state: RootState) => state.inventory.error
export const selectInventoryPagination = (state: RootState) => ({
  page: state.inventory.page,
  limit: state.inventory.limit,
  total: state.inventory.total,
  totalPages: state.inventory.totalPages,
})
export const selectInventoryFilters = (state: RootState) => state.inventory.filters
export const selectInventorySearch = (state: RootState) => state.inventory.search
export const selectInventorySort = (state: RootState) => state.inventory.sort
export const selectSelectedInventoryItem = (state: RootState) => state.inventory.selectedItem
export const selectStockMovements = (state: RootState) => state.inventory.stockMovements
export const selectStockAdjustments = (state: RootState) => state.inventory.stockAdjustments
export const selectRecipes = (state: RootState) => state.inventory.recipes

// Export reducer
export default inventorySlice.reducer