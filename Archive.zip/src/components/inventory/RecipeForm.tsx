// components/inventory/RecipeForm.tsx
"use client"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../../components/ui/form"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const formSchema = z.object({
  menuItemId: z.string().min(1, "Menu item is required"),
  ingredientId: z.string().min(1, "Ingredient is required"),
  quantity: z
    .number({ invalid_type_error: "Quantity is required" })
    .min(0.01, "Quantity must be positive"),
})

interface RecipeFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: {
    menuItemId: string
    ingredients: { ingredientId: string; quantity: number }[]
  }) => void
  inventoryItems: { id: string; name: string; unit: string }[]
}

export function RecipeForm({ open, onOpenChange, onSubmit, inventoryItems }: RecipeFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      menuItemId: "",
      ingredientId: "",
      quantity: 0,
    },
  })

  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    const payload = {
      menuItemId: values.menuItemId,
      ingredients: [
        {
          ingredientId: values.ingredientId,
          quantity: values.quantity,
        },
      ],
    }

    onSubmit(payload)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Recipe</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="menuItemId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Menu Item ID</FormLabel>
                  <FormControl>
                    <Input placeholder="Menu item ID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="ingredientId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ingredient ID</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingredient ID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="0.01"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Add Recipe</Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
